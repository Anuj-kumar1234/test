package com.test.hc;

public class Customer {
 private int AccountType;
 
private String name;
 private String address;
 private int age;
 private String mobileNumber;
 private int purchasedAmount;
public int getAccountType() {
		return AccountType;
	}
 public void setAccountType(int accountType) {
		AccountType = accountType;
	}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public String displayCustomer()
{
	return "Name "+ " "+name+ "/n"+"Mobile" +" "+mobileNumber+ "/n"+"Age"+ " "+age+ "/n"+"Address"+" "+address;
			
}
public int getPurchasedAmount() {
	return purchasedAmount;
}
public void setPurchasedAmount(int purchasedAmount) {
	this.purchasedAmount = purchasedAmount;
}

 
}
