package com.test.hc;

public class PrivilegeCustomer extends Customer {
	public Double generateBillAmount(double amount)
	{
		amount =amount*0.30;
		return amount;
	}

	

}
