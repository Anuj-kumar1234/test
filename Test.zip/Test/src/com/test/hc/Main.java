package com.test.hc;


import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		PrivilegeCustomer pc=new PrivilegeCustomer();
		SeniorCitizenCustomer scc=new SeniorCitizenCustomer();
		Scanner sc=new Scanner(System.in);
		Customer cust[]=new Customer[1];
		for(int i=0;i<cust.length;i++)
		{
			System.out.println("1)Privilege Customer");
			System.out.println("2)SeniorCitizenCustomer");
			cust[i]=new Customer();
			System.out.println("Enter Customer Type");
			cust[i].setAccountType(sc.nextInt());
			System.out.println("Enter The Name");
			cust[i].setName(sc.next());
			System.out.println("Enter The Age");
			cust[i].setAge(sc.nextInt());
			System.out.println("Enter The Address");
			cust[i].setAddress(sc.next());
			System.out.println("Enter The Mobile Number");
			cust[i].setMobileNumber(sc.next());
			System.out.println("Enter The Purchased Amount");
			cust[i].setPurchasedAmount(sc.nextInt());
	
		}
		for(Customer re:cust)
		{
			System.out.println(re.displayCustomer());
		}
		if(cust[0].getAccountType()==1)
		{
			System.out.println("Your bill Amount is Rs"+cust[0].getPurchasedAmount()+".Your bill amount is discount under privilege customer \n You have to pay Rs"+""+pc.generateBillAmount(cust[0].getPurchasedAmount()));

		}
		else
		{
			System.out.println("Your bill Amount is Rs"+cust[0].getPurchasedAmount()+".Your bill amount is discount under SeniorCitizenCustomer customer \n You have to pay Rs"+""+scc.generateBillAmount(cust[0].getPurchasedAmount()));

		}
        
	}

}
